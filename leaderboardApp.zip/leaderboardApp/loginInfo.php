<?php
	
	define('DB_HOST', 'localhost');
	define('USERNAME', '');
	define('PASSWORD', '');
	define('DB_NAME', '');
	
?>