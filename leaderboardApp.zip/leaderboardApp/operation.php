<?php

class operation {
	private $conn;
	
	function __construct() {
		
		//creating the connection to perform operations
		require_once dirname(__FILE__) . '/connect.php';
		$op = new connect();
		$this->conn = $op->connect();
		
	}
	//adds a score to the database, must add all team scores at the same time
	public function addScores($team1, $team2, $team3, $team4, $team5) {
		$stmt = $this->conn->prepare("INSERT INTO scores (team1, team2, team3, team4, team5) VALUES (?,?,?,?,?)");
		$stmt->bind_param("iiiii", $team1, $team2, $team3, $team4, $team5);
		if($stmt->execute()) {
			return true;
		return false;
		}	
	}
	
	//returns scores from the database to the app via an SQL statement, could break this out to only return a specific score from one team
	public function getScores() {
		$stmt = this->conn->prepare("SELECT team1, team2, team3, team4, team5 FROM scores");
		$stmt->execute();
		$stmt->bind_result($team1, $team2, $team3, $team4, $team5);
		$scoresArr = array();
		
		while($stmt->fetch()) {
			$tempArr = array();
			$tempArr['team1'] = $team1;
			$tempArr['team2'] = $team2;
			$tempArr['team3'] = $team3;
			$tempArr['team4'] = $team4;
			$tempArr['team5'] = $team5;
			
			array_push($scoresArr, $tempArr);
		}
		
		return $scoresArr;
	}
	
	//delete scores from a specific team
	public function deleteScores() {
		
		if($deleteType = 0) {
			$stmt->conn->prepare("DELETE team1, team2, team3, team4, team5 FROM scores");
			if($stmt->execute()) { 
				return true;
			return false;
			}
		} else {
		
		//if the user wants to delete a score from one specific team (team1)
			($deleteType = 1) {
			$stmt = this->conn->prepare("DELETE team1 FROM scores");
			if($stmt->execute()) {
				return true;
			return false;
			}
		} else {
			//team2 deletion
			($deleteType = 2) {
			$stmt = this->conn->prepare("DELETE team2 FROM scores");
			if($stmt->execute()) {
				return true;
			return false;
			}
			
		} else {
			//team3 deletion
			($deleteType = 3) {
			$stmt = this->conn->prepare("DELETE team3 FROM scores");
			if($stmt->execute()) {
				return true;
			return false;
			
		} else	{
			//team4 deletion
			($deleteType = 4) {
			$stmt = this->conn->prepare("DELETE team4 FROM scores");
			if($stmt->execute()) {
				return true;
			return false;
		} else {
			
			//team5 deletion
			($deleteType = 5) {
			$stmt = this->conn->prepare("DELETE team5 FROM scores");
			if($stmt->execute()) {
				return true;
			return false;
		}
	}	
}