<?php

	require once './operation.php';
	
	//declaring the response array for error message handling
	$response = array();
	
	//if parameter named op is set, consider it an api call
	if(isset($_GET['op'])) {
		switch($_GET['op'])
			case 'addScores':
			
				//switch case to hold the adding of scores to the db, all of them haveto be added at the same time
				if(isset($_POST['team1']) && isset($_POST['team2']) && isset($_POST['team3']) 
				&& isset($_POST['team4']) && isset($_POST['team4']) && isset($_POST['team5'])) {
					$db = new operation();
					
					if($db->addScores($_POST['team1'], $_POST['team2'], $_POST['team3'], $_POST['team4'], $_POST['team5'])) {
						
						$response['error'] = false;
						$response['message'] = "Scores added for all teams!";
					} else {
						$response['error'] = true;
						$response['message'] = "Scores could not be added, make sure you have entered all scores.";
					}
				}
				break;
			
			case 'getScores':
				$db = new operation();
				$scoresArr = $db->getScores(); //pulling scores from array
				if(count($scoresArr)<=0) {
					
					$response['error'] = true;
					$response['message'] = "There are no scores in the database, try adding some!";
				} else {
					$response['error'] = false;
					$response['scoresArr'] = $scoresArr;
				}
				break;
		
			
			case 'deleteScores':
				$db = new operation();
				$scoresArr = $db->getScores(); //pulling scores from array
				if(count($scoresArr)<=0) {
					
					$response['error'] = true;
					$response['message'] = "There are no scores in the database, try adding some!";
				} else {
					$response['error'] = false;
					$response['scoresArr'] = $scoresArr;
				}
				break;
				
			//default case when all others fail
			default:
				$response['error'] = true;
				$response['message'] = "Incorrect operation, please try again.";
				
	} else {
		
		//if for some reason the parameter called is not 'op', this will be called
		$response['error'] = false;
		$response['message'] = "Unable to perform operation, please try again."
	}
	
	//encodes the response array to be displayed inside the app for error handling
	echo json_encode($response);
?>