<! A simple page to add information to a database containing names of teams and scores of resulting teams for a trivia night.>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Post Scores</title>
		<link href="style.css" type="text/css" rel="stylesheet">
	</head>
	<body>
		<form name="submission" action="connect.php" method="post"/>
			<div class="container">
				<div class="form_group">
					<label>Type the number of teams</label>
					<input type="text" name="teamNum" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 1: </label>
					<input type="text" name="team1" value=""/>
				</div>
			
				<div class="form_group">
					<label>Team 2: </label>
					<input type="text" name="team2" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 3: </label>
					<input type="text" name="team3" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 4: </label>
					<input type="text" name="team4" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 5: </label>
					<input type="text" name="team5" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 6: </label>
					<input type="text" name="team6" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 7: </label>
					<input type="text" name="team7" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 8: </label>
					<input type="text" name="team8" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 9: </label>
					<input type="text" name="team9" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 10: </label>
					<input type="text" name="team10" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 11: </label>
					<input type="text" name="team11" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 12: </label>
					<input type="text" name="team12" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 13: </label>
					<input type="text" name="team13" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 14: </label>
					<input type="text" name="team14" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 15: </label>
					<input type="text" name="team15" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 16: </label>
					<input type="text" name="team16" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 17: </label>
					<input type="text" name="team17" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 18: </label>
					<input type="text" name="team18" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 19: </label>
					<input type="text" name="team19" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 20: </label>
					<input type="text" name="team20" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 21: </label>
					<input type="text" name="team21" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 22: </label>
					<input type="text" name="team22" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 23: </label>
					<input type="text" name="team23" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 24: </label>
					<input type="text" name="team24" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 25: </label>
					<input type="text" name="team25" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 26: </label>
					<input type="text" name="team26" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 27: </label>
					<input type="text" name="team27" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 28: </label>
					<input type="text" name="team28" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 29: </label>
					<input type="text" name="team29" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 30: </label>
					<input type="text" name="team30" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 31: </label>
					<input type="text" name="team31" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 32: </label>
					<input type="text" name="team32" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 33: </label>
					<input type="text" name="team33" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 34: </label>
					<input type="text" name="team34" value=""/>
				</div>
				
				<div class="form_group">
					<label>Team 35: </label>
					<input type="text" name="team35" value=""/>
				</div>
				<button type="submit" formmethod="post">Submit Scores</button>
			</div>
	</body>		
</html>
	
	
	
	
	