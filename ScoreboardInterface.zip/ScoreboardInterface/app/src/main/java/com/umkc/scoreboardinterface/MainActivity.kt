package com.umkc.scoreboardinterface

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.view.Gravity
import android.view.LayoutInflater
import kotlinx.android.synthetic.main.activity_main.*
import android.content.Context
import android.os.Build
import android.transition.Slide
import android.transition.Transition
import android.transition.TransitionManager
import android.widget.*

//sql interface imports
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import org.json.JSONException
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    //edit txt and spinner
    private var editText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //get view ID's for buttons
        val resetButton = findViewById<Button>(R.id.reset)
        val postButton = findViewById<Button>(R.id.post)
        val settingsButton = findViewById<Button>(R.id.settings)

        resetButton.setOnClickListener{
            //do reset stuff here
        }


        postButton.setOnClickListener {
            //do post stuff here
        }

        //reused popup window code from AndroidBuddy project
        settingsButton.setOnClickListener {
            aboutButton.setOnClickListener {
                //initialize new layout inflater
                val inflater:LayoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

                //inflate a custom view via layout inflater
                val view = inflater.inflate(R.layout.another_view, null)

                //initialize a new popup window
                LinearLayout.LayoutParams params = layout.getLayoutParams()
                params.height = 300;
                params.width = 300;

                val popup = PopupWindow(view, LinearLayout.LayoutParams.params.height, LinearLayout.LayoutParams.width)

                //if the popup api version is 23 or greater
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    //create new slide animation
                    val slideIn = Slide()
                    slideIn.slideEdge = Gravity.TOP
                    popup.enterTransition = slideIn

                    //slide animation for slide out
                    val slideOut = Slide()
                    slideOut.slideEdge = Gravity.RIGHT
                    popup.exitTransition = slideOut
                }

                //get widget ref ID
                val popupText = view.findViewById<TextView>(R.id.popupText)
                val exitPopup = view.findViewById<Button>(R.id.exitPopup)

                //popup exit button listener
                exitPopup.setOnClickListener() {
                    popup.dismiss()
                }

                //show the popup window inside the app
                TransitionManager.beginDelayedTransition(root_layout)
                popup.showAtLocation(root_layout, Gravity.CENTER, 0, 0)
            }

        }

        //add score to the sql db
        private fun addScore() {
            //getting the record values
            val team = editTeam?.text.toString()
            val score = spinnerScore?.selectedItem.toString()

            //creating volley string request
            val stringRequest = object : StringRequest(Request.Method.POST, EndPoints.URL_ADD_SCORE,
                Response.Listener<String> { response ->
                    try {
                        val obj = JSONObject(response)
                        Toast.makeText(applicationContext, obj.getString("message"), Toast.LENGTH_LONG).show()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                object : Response.ErrorListener {
                    override fun onErrorResponse(volleyError: VolleyError) {
                        Toast.makeText(applicationContext, volleyError.message, Toast.LENGTH_LONG).show()
                    }
                }) {
                @Throws(AuthFailureError::class)
                override fun getParams(): Map<String, String> {
                    val params = HashMap<String, String>()
                    params.put("Score", score)
                    params.put("Teams", team)
                    return params
                }
            }
    }

}
