package com.umkc.scoreboardinterface

object EndPoints {
    private val URL_ROOT = "http://71.10.216.1/webApp/?op="
    val URL_ADD_SCORES = URL_ROOT + "addScores"
    val URL_DELETE_SCORES = URL_ROOT + "deleteScores"
    val URL_GET_SCORES = URL_ROOT + "getScores"
}